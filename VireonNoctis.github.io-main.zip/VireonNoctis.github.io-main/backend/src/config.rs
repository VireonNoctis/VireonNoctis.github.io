use std::time::Duration;
#[derive(Clone)]
pub struct Config { pub anilist_username: String, pub github_username: String, pub lastfm_username: String, pub lastfm_api_key: String, pub cache_ttl: Duration }
impl Config {
    pub fn from_env() -> Self {
        Self {
            anilist_username: std::env::var("ANILIST_USERNAME").unwrap_or_else(|_| "Vireon".into()),
            github_username: std::env::var("GITHUB_USERNAME").unwrap_or_else(|_| "VireonNoctis".into()),
            lastfm_username: std::env::var("LASTFM_USERNAME").unwrap_or_else(|_| "reasfeetadmirer".into()),
            lastfm_api_key: std::env::var("LASTFM_API_KEY").unwrap_or_default(),
            cache_ttl: Duration::from_secs(std::env::var("CACHE_TTL_SECONDS").ok().and_then(|v| v.parse().ok()).unwrap_or(900)),
        }
    }
}
