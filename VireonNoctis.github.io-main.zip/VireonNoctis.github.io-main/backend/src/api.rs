use reqwest::{Client, Method};
use serde_json::Value;
use std::time::Duration;

#[derive(Clone)]
pub struct ApiClient { client: Client }
impl ApiClient {
    pub fn new() -> Result<Self, reqwest::Error> {
        Ok(Self { client: Client::builder().timeout(Duration::from_secs(12)).user_agent("VireonNoctis/1.0 (+https://vireonnoctis.github.io)").build()? })
    }
    pub async fn get_json(&self, url: &str) -> Option<Value> { self.request(Method::GET, url, None).await }
    pub async fn post_json(&self, url: &str, body: &Value) -> Option<Value> { self.request(Method::POST, url, Some(body)).await }
    async fn request(&self, method: Method, url: &str, body: Option<&Value>) -> Option<Value> {
        let mut req = self.client.request(method, url).header("Accept", "application/json");
        if let Some(value) = body { req = req.json(value); }
        match req.send().await {
            Ok(response) if response.status().is_success() => response.json::<Value>().await.ok(),
            Ok(response) => { eprintln!("[api] upstream returned {}", response.status()); None }
            Err(error) => { eprintln!("[api] request failed: {error}"); None }
        }
    }
}
