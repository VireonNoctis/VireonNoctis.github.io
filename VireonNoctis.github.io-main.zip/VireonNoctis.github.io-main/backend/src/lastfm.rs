use crate::{api::ApiClient, cache::Cache, config::Config};
use serde_json::{json, Value};
use url::form_urlencoded::Serializer;

async fn request(api: &ApiClient, config: &Config, method: &str, extra: &[(&str, &str)]) -> Option<Value> {
    if config.lastfm_api_key.is_empty() { return None; }
    let mut query = Serializer::new(String::new());
    query.append_pair("method", method).append_pair("api_key", &config.lastfm_api_key).append_pair("format", "json").append_pair("user", &config.lastfm_username);
    for (key, value) in extra { query.append_pair(key, value); }
    api.get_json(&format!("https://ws.audioscrobbler.com/2.0/?{}", query.finish())).await
}
pub async fn get_now_playing(api: &ApiClient, cache: &Cache, config: &Config) -> Option<Value> {
    let key = format!("lastfm:recent:{}", config.lastfm_username);
    if let Some(value) = cache.get(&key) { return Some(value); }
    let data = request(api, config, "user.getrecenttracks", &[("limit","1")]).await?;
    let track = data.pointer("/recenttracks/track/0")?;
    let value = json!({"playing":track.pointer("/@attr/nowplaying").and_then(Value::as_str)==Some("true"),"track":track["name"],"artist":track["artist"]["#text"],"album":track["album"]["#text"],"cover":track["image"].as_array().and_then(|a|a.last()).and_then(|v|v.get("#text")),"url":track["url"]});
    cache.set(key, value.clone(), config.cache_ttl);
    Some(value)
}
pub async fn get_stats(api: &ApiClient, cache: &Cache, config: &Config) -> Option<Value> {
    let key = format!("lastfm:stats:{}", config.lastfm_username);
    if let Some(value) = cache.get(&key) { return Some(value); }
    let user = request(api, config, "user.getinfo", &[]).await?.get("user")?.clone();
    let value = json!({"username":user["name"],"avatar":user["image"].as_array().and_then(|a|a.last()).and_then(|v|v.get("#text")),"scrobbles":user["playcount"].as_str().and_then(|v|v.parse::<u64>().ok()),"registered":user["registered"]["unixtime"]});
    cache.set(key, value.clone(), config.cache_ttl);
    Some(value)
}
