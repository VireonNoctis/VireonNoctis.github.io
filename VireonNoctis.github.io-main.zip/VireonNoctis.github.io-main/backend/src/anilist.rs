use crate::{api::ApiClient, cache::Cache, config::Config, scrapers::anilist_scraper};
use serde_json::{json, Value};

pub async fn get_profile(api: &ApiClient, cache: &Cache, config: &Config) -> Option<Value> {
    let key = format!("anilist:{}", config.anilist_username);
    if let Some(value) = cache.get(&key) { return Some(value); }
    let query = r#"query($username:String){User(name:$username){id name avatar{large} about statistics{anime{count episodesWatched minutesWatched meanScore formats{format count}} manga{count chaptersRead volumesRead meanScore formats{format count}}}}}"#;
    let raw = api.post_json("https://graphql.anilist.co", &json!({"query":query,"variables":{"username":config.anilist_username}})).await;
    let user = raw.as_ref().and_then(|v| v.pointer("/data/User")).cloned()
        .or_else(|| None);
    let value = if let Some(user) = user {
        let anime = user.pointer("/statistics/anime").cloned().unwrap_or_default();
        let manga = user.pointer("/statistics/manga").cloned().unwrap_or_default();
        json!({"username":user["name"],"avatar":user.pointer("/avatar/large"),"about":user["about"],
          "anime":{"total":anime["count"],"episodes":anime["episodesWatched"],"minutes":anime["minutesWatched"],"score":anime["meanScore"],"formats":anime["formats"]},
          "manga":{"total":manga["count"],"chapters":manga["chaptersRead"],"volumes":manga["volumesRead"],"score":manga["meanScore"],"formats":manga["formats"]}})
    } else {
        let user = anilist_scraper::profile(api, &config.anilist_username).await?;
        json!({"username":user["name"],"profile":{"id":user["id"],"name":user["name"],"avatar":user.pointer("/avatar/large"),"banner":user["bannerImage"],"about":user["about"]},
          "statistics":{"anime":user["statistics"]["anime"],"manga":user["statistics"]["manga"]},
          "favorites":{"anime":user["favourites"]["anime"]["nodes"],"manga":user["favourites"]["manga"]["nodes"]}})
    };
    cache.set(key, value.clone(), config.cache_ttl);
    Some(value)
}
