use crate::{api::ApiClient, cache::Cache, config::Config};
use serde_json::{json, Value};

pub async fn get_profile(api: &ApiClient, cache: &Cache, config: &Config) -> Option<Value> {
    let key = format!("github:profile:{}", config.github_username);
    if let Some(value) = cache.get(&key) { return Some(value); }
    let raw = api.get_json(&format!("https://api.github.com/users/{}", config.github_username)).await?;
    let value = json!({"username":raw["login"],"avatar":raw["avatar_url"],"name":raw["name"],"bio":raw["bio"],"followers":raw["followers"],"following":raw["following"],"repositories":raw["public_repos"],"created":raw["created_at"],"profile":raw["html_url"]});
    cache.set(key, value.clone(), config.cache_ttl);
    Some(value)
}
pub async fn get_repositories(api: &ApiClient, cache: &Cache, config: &Config) -> Vec<Value> {
    let key = format!("github:repos:{}", config.github_username);
    if let Some(value) = cache.get(&key) { return value.as_array().cloned().unwrap_or_default(); }
    let Some(raw) = api.get_json(&format!("https://api.github.com/users/{}/repos?per_page=100&sort=updated", config.github_username)).await else { return Vec::new() };
    let repos: Vec<Value> = raw.as_array().into_iter().flatten().map(|repo| json!({"name":repo["name"],"description":repo["description"],"stars":repo["stargazers_count"],"forks":repo["forks_count"],"language":repo["language"],"url":repo["html_url"]})).collect();
    cache.set(key, Value::Array(repos.clone()), config.cache_ttl);
    repos
}
