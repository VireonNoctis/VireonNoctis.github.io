use serde_json::Value;
use std::{collections::HashMap, sync::{Arc, RwLock}, time::{Duration, Instant}};

#[derive(Clone, Default)]
pub struct Cache { entries: Arc<RwLock<HashMap<String, (Value, Instant)>>> }
impl Cache {
    pub fn get(&self, key: &str) -> Option<Value> {
        let mut entries = self.entries.write().ok()?;
        match entries.get(key) {
            Some((value, expires)) if Instant::now() < *expires => Some(value.clone()),
            Some(_) => { entries.remove(key); None },
            None => None
        }
    }
    pub fn set(&self, key: impl Into<String>, value: Value, ttl: Duration) {
        if let Ok(mut entries) = self.entries.write() { entries.insert(key.into(), (value, Instant::now() + ttl)); }
    }
    pub fn clear(&self) { if let Ok(mut entries) = self.entries.write() { entries.clear(); } }
}
