use crate::{anilist, api::ApiClient, cache::Cache, components, config::Config, github, lastfm};
use serde_json::{json, Value};

pub async fn load(api: &ApiClient, cache: &Cache, config: &Config) -> Value {
    let (gh, al, lf, recent, repos) = tokio::join!(
        github::get_profile(api, cache, config),
        anilist::get_profile(api, cache, config),
        lastfm::get_stats(api, cache, config),
        lastfm::get_now_playing(api, cache, config),
        github::get_repositories(api, cache, config)
    );
    json!({"github":gh.as_ref().map(components::github_card::view),
      "anilist":al.as_ref().map(components::anilist_card::view),
      "lastfm":lf.as_ref().map(|v|components::lastfm_card::view(v,recent.as_ref())),
      "stats":components::stats_card::view(gh.as_ref(),al.as_ref(),lf.as_ref()),"repositories":repos})
}
