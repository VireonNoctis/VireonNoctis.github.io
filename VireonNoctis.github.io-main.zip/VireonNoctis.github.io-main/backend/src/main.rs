mod anilist;
mod api;
mod cache;
mod components;
mod config;
mod github;
mod lastfm;
mod scrapers;

use axum::{http::StatusCode, routing::get, Json, Router};
use serde::Serialize;
use std::{env, net::SocketAddr, sync::Arc};

#[derive(Clone)]
struct AppState {
    api: api::ApiClient,
    cache: cache::Cache,
    config: config::Config,
}

#[derive(Debug, Serialize, PartialEq)]
struct Health {
    status: &'static str,
    service: &'static str,
}

#[derive(Debug, Serialize, PartialEq)]
struct SiteInfo {
    name: &'static str,
    frontend: &'static str,
    hosting_note: &'static str,
}

async fn health() -> Json<Health> {
    Json(Health { status: "ok", service: "vireon-noctis-api" })
}

async fn site_info() -> Json<SiteInfo> {
    Json(SiteInfo {
        name: "Vireon Noctis",
        frontend: "Next.js static export",
        hosting_note: "This API is a separate service; GitHub Pages hosts only the static frontend.",
    })
}


fn app(state: Arc<AppState>) -> Router {
    Router::new()
        .route("/health", get(health))
        .route("/api/v1/site", get(site_info))
        .with_state(state)
}

#[tokio::main]
async fn main() {
    let api = api::ApiClient::new().expect("failed to initialize HTTP client");
    let state = Arc::new(AppState { api, cache: cache::Cache::default(), config: config::Config::from_env() });
    let host = env::var("HOST").unwrap_or_else(|_| "0.0.0.0".to_owned());
    let port = env::var("PORT").ok().and_then(|v| v.parse::<u16>().ok()).unwrap_or(8080);
    let address: SocketAddr = format!("{host}:{port}").parse().expect("HOST and PORT must form a valid socket address");
    let listener = tokio::net::TcpListener::bind(address).await.expect("failed to bind API listener");
    println!("Vireon Noctis Rust API listening on http://{address}");
    axum::serve(listener, app(state)).await.expect("API server failed");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn health_endpoint_returns_service_identity() {
        let Json(payload) = health().await;
        assert_eq!(payload.status, "ok");
        assert_eq!(payload.service, "vireon-noctis-api");
    }

    #[tokio::test]
    async fn site_endpoint_is_clear_about_static_hosting() {
        let Json(payload) = site_info().await;
        assert_eq!(payload.frontend, "Next.js static export");
        assert!(payload.hosting_note.contains("GitHub Pages"));
    }
}
